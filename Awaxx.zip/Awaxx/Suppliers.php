<?php
require_once 'controllers/authController.php';
require_once 'controllers/suppliersMgmt.php';
    session_start();

if(!isset($_SESSION['id'])){
  header('location: Login.php');
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Awaxx Technologies - Suppliers Management System</title>

  <!-- Bootstrap core CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
  <!--===============================================================================================-->
  <script src="https://kit.fontawesome.com/4f8eb25e26.js" crossorigin="anonymous"></script>

  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">




  <!-- Custom styles for this template -->
  <link href="Style/Dashboard/simple-sidebar.css" rel="stylesheet">
  <link href="Style/Dashboard/dashstyle.css" rel="stylesheet">


</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Awaxx Technologies</div>
      <div class="list-group list-group-flush">
        <a href="Dashboard.php" class="item list-group-item list-group-item-action"><span class="fa fa-dashboard"></span>  &nbsp;Dashboard</a>
        <a href="Sales.php" class="item list-group-item list-group-item-action"><span class="fas fa-cash-register"></span>  &nbsp;Sales Transactions</a>
        <a href="Products.php" class="item list-group-item list-group-item-action"><span class="fa fa-industry"></span>  &nbsp;Products Inventory</a>
        <a href="Purchases.php" class="item list-group-item list-group-item-action"><span class="fa fa-shopping-bag"></span> &nbsp;Purchases Management</a>
        <a href="Expenses.php" class="item list-group-item list-group-item-action"><span class="fas fa-wallet"></span> &nbsp;Expenses Management</a>
        <a href="Accounts.php" class="item list-group-item list-group-item-action"><span class="fas fa-file-alt	"></span> &nbsp;Accounts Management</a>
        <a href="Customers.php" class="item list-group-item list-group-item-action"><span class="fas fa-handshake"></span>&nbsp;Customers Management</a>
        <a href="Suppliers.php" class="item-active list-group-item list-group-item-action"><span class="fas fa-truck-moving"></span>  &nbsp;Suppliers Management</a>
        <a href="Employee.php" class="item list-group-item list-group-item-action"><span class="fas fa-user-tie"></span>  &nbsp;Employees Management</a>
        <a href="Users.php" class="item list-group-item list-group-item-action"><span class="fas fa-portrait"></span> &nbsp;Users Management</a>
        <a href="Profile.php" class="item list-group-item list-group-item-action"><span class="fas fa-address-card"></span>  &nbsp;Profile Settings</a>
        <a href="Dashboard.php?logout=1" class="logout item list-group-item list-group-item-action item"><span class="fas fa-sign-out-alt"></span> &nbsp;Logout</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
      <button style="width: 5rem;" class="tbtn btn btn-primary" id="menu-toggle"><span><i class="fa fa-reorder"></i></span></button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Suppliers Management <span class="sr-only">(current)</span></a>
            </li>
            <li style=" color:#00b0d8;" class="nav-item nav-link">How's it going,  <?php echo $_SESSION['username']; ?></li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">
        <h1 class="mt-4"> <span class="fa fa-truck"></span>  &nbsp;Suppliers Management</h1>
        <br>

        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
          <?php foreach ($errors as $error): ?>

          <li> <?php echo $error; ?> </li>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if(count($success) > 0): ?>
        <div class="alert alert-success">
          <?php foreach ($success as $succeses): ?>

          <li> <?php echo $succeses; ?> </li>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div style="margin-left: 2px;" class="card info"  style="width: 21rem; height: 15rem;">
          <div class="card-body">
            <h2 class="card-title"><span class="fa fa-bar-chart"></span> &nbsp; Latest Added Suppliers</h1><br>
              <button type="button" style="margin: 20px 50px; " id="#showaddsuppliermodal" class="mtbtn tbtn btn btn-primary" data-toggle="modal" data-target="#addSupplierModal"> Add new Supplier </button>
              <button type="button" style="margin: 20px 50px; " id="#showeditsuppliermodal" class="mtbtn1 tbtn btn btn-primary" data-toggle="modal" data-target="#editSupplierModal"> Edit / Delete Supplier </button>
              <div class="table-responsive">
        <table style="text-align: center; margin-top:2%;" id="customerstable" class="table cell-border order-column table-hover row-border">
  <thead>
    <tr>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Supplier ID</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Supplier Name</th>
      <th style="background-color: #00b0d8; color: #fff;"scope="col">Supplier Email </th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Supplier Phone</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Supplier Address</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Supplier Segment</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Supplier Contact Mode</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">First Time Added</th>
    </tr>
  </thead>
  <tbody>

    <?php
        $sqlcd = "SELECT SupplierID, Name, Email, Phone, Address, Segment, SupplierCM, TimeAdded FROM suppliers  ORDER BY `suppliers`.`TimeAdded` DESC";
        $resultcd = $conn->query($sqlcd);
        if ($resultcd->num_rows > 0) {
        // output data of each row
        while($row = $resultcd->fetch_assoc()) {
        echo "<tr>
        <th>" . $row['SupplierID']. "</th>
        <th>" . $row["Name"]. "</th>
        <td>" . $row["Email"] . " </td>
        <td>" . $row["Phone"] . " </td>
        <td>" . $row["Address"]. "</td>
        <td>" . $row["Segment"]. "</td>
        <td>" . $row["SupplierCM"]. "</td>
        <td>" . $row["TimeAdded"]. "</td>
        </tr>";
        }


        $conn->close();
      }
         ?>

  </tbody>
</table>
</div>

    </div>
  </div>
    <div class="modal fade" id="addSupplierModal" tabindex="-1" role="dialog"   aria-labelledby="addSupplierLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content" style="width: 41rem; margin-left: -15%;">
          <div class="modal-header">
            <h5 class=" modal-title" id="addSupplierLabel"></h5>
            <button type="button" class="close" style="cursor: pointer !important;" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body" >
            <div class="card" style="width: 39rem;" >
              <div class="card-header text-center">
                <strong> Record a New Supplier Data </strong>
              </div>
              <div class="card-body">
            <h5 class="card-title text-center">Add a new Supplier</h5>
            <p class="card-text text-center">Fill the fileds below to add a new Supplier.</p>
            <br>
            <form method="POST" action="Suppliers.php?addsupplier">
                <fieldset>
                  <legend>Communication Details</legend>
                  <hr>
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="suppliername">Supplier Name</label>
                    <input type="text" class="form-control" name="SupplierName" id="suppliername" required placeholder="Supplier Name">
                  </div>
                  <div class="form-group col-md-6">
                    <label for="supplieremail">Email Address</label>
                    <input type="email" class="form-control" name="SupplierEmail" id="supplieremail" placeholder="Supplier Email Address">
                  </div>
                  <div class="form-group col-md-6">
                    <label for="supplierphone">Phone Number</label>
                    <input type="tel" class="form-control" name="SupplierPhone" id="supplierphone" placeholder="Supplier Phone Number">
                  </div>
                </div>
                  <div class="form-row">
                <div class="form-group col-md-6 ">
                  <label for="suppaddr">Physical Address</label>
                    <input type="text" class="form-control" name="SupplierAddress" id="suppaddr" placeholder="Supplier Physical Address">
                </div>
                <div class="form-group col-md-6">
                  <label for="suppliercontmod">Mode of Contact</label>
                  <select name="SupplierContactMode" id="suppliercontmod" class="form-control">
                    <option selected>Choose Mode of Contact</option>
                    <option value="Email">Email</option>
                    <option value="Phone" > Phone</option>
                    <option value="IM">IM </option>
                  </select>
                </div>
              </div>
              </fieldset>
              <hr>
              <fieldset>
                <legend>Profile Details</legend>
                <hr>
                  <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="supplierrank">Supplier Segment</label>
                    <select  name="SupplierSegment" id="supplierrank" class="form-control">
                      <option selected>Choose Supplier Segment</option>
                      <option value="A">A</option>
                      <option value="B">B</option>
                      <option value="C">C</option>
                    </select>
                  </div>

              </div>
            </fieldset>

          <div class="card-footer text-center text-muted">
            <?php echo date("Y-m-d H:i:s"); ?>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="mbtn btn btn-secondary" data-dismiss="modal">Close</button>
        <button  type="submit" name="addSupplier-btn" class="mbtn btn btn-primary">Add Supplier</button>
      </div>
      </form>

    </div>
  </div>
</div>
</div>

  <!-- /#wrapper -->
  <div class="modal fade" id="editSupplierModal" tabindex="-1" role="dialog" aria-labelledby="editSupplierLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content" style="width: 41rem; margin-left: -15%;">
        <div class="modal-header">
          <h5 class=" modal-title" id="editSupplierLabel"></h5>
          <button type="button" class="close" style="cursor: pointer !important;" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" >
          <div class="card" style="width: 39rem;" >
            <div class="card-header text-center">
              <strong> Edit Existing Supplier Data </strong>
            </div>
            <div class="card-body">
          <h5 class="card-title text-center">Edit Exiting Supplier Data</h5>
          <p class="card-text text-center">Search for supplier by Supplier ID then edit existing supplier data by edit the fileds below. to delete the supplier just search for supplier by Supplier ID  then click on delete button.</p>
          <br>
          <form method="POST" @submit.prevent="validationCategoryUnit" action="Suppliers.php?editsupplier">
            <div class="form-row">
                <div class="form-group col-md-8">
                  <label for="supplierid">Supplier ID</label>
                  <input type="text" class="form-control" name="esupplierid" id="supplierid" required value="<?php echo $_SESSION['sID']; ?>" placeholder="Input Supplier ID You are looking for">
                </div><!-- Seaching -->
                <div class="form-group col-md-3">
                  <button type="submit" style="width:9rem; margin-top: 32px;" name="searchSupplier-btn" id="searchdata" onclick="$('#editSupplierModal').modal({'backdrop': 'static'});" class="tbtn btn btn-primary btn-search"> Search  </button>
                </div>
            </div>
              <fieldset>
                <legend>Communication Details</legend>
                <hr>
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="esuppliername">Supplier Name</label>
                  <input type="text" class="form-control" name="eSupplierName" id="esuppliername" placeholder="Supplier Name" value="<?php echo $_SESSION['sName']; ?>" >
                </div>
                <div class="form-group col-md-6">
                  <label for="esuppemail">Email Address</label>
                  <input type="email" class="form-control" name="eSupplierEmail" id="esuppemail" placeholder="Supplier Email Address" value="<?php echo $_SESSION['sEmail']; ?>">
                </div>
                <div class="form-group col-md-6">
                  <label for="esuppphone">Phone Number</label>
                  <input type="tel" class="form-control" name="eSupplierPhone" id="esuppphone" placeholder="Supplier Phone Number" value="<?php echo $_SESSION['sPhone']; ?>" >
                </div>
              </div>
                <div class="form-row">
              <div class="form-group col-md-6 ">
                <label for="esuppaddr">Physical Address</label>
                  <input type="text" class="form-control" name="eSupplierAddress" id="esuppaddr" placeholder="Supplier Physical Address" value="<?php echo $_SESSION['sAddress']; ?>" >
              </div>
              <div class="form-group col-md-6">
                <label for="escontmod">Mode of Contact</label>
                <select name="eSupplierContactMode" id="escontmod" class="form-control">
                  <option selected>Choose Mode of Contact</option>
                  <option value="Email" <?php if($_SESSION['sContactM']=="Email") echo ' selected'; ?>>Email</option>
                  <option value="Phone" <?php if($_SESSION['sContactM']=="Phone") echo ' selected'; ?>>Phone</option>
                  <option value="IM" <?php if($_SESSION['sContactM']=="IM") echo ' selected'; ?>>IM </option>
                </select>
              </div>
            </div>
            </fieldset>
            <hr>
            <fieldset>
              <legend>Profile Details</legend>
              <hr>
                <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="supplierseg">Supplier Segment</label>
                  <select name="eSupplierSegment" id="supplierseg" class="form-control">
                    <option selected>Choose Supplier Segment</option>
                    <option value="A" <?php if($_SESSION['sSegment']=="A") echo ' selected'; ?> >A</option>
                    <option value="B" <?php if($_SESSION['sSegment']=="B") echo ' selected'; ?> >B</option>
                    <option value="C" <?php if($_SESSION['sSegment']=="C") echo ' selected'; ?>>C</option>
                  </select>
                </div>
            </div>
          </fieldset>

        <div class="card-footer text-center text-muted">
          <?php echo date("Y-m-d H:i:s"); ?>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="mbtn btn btn-secondary" data-dismiss="modal">Close</button>
      <button type="submit" name="deleteSupplier-btn" class="mbtn btn btn-primary">Delete Supplier</button>
      <button  type="submit" name="editSupplier-btn" class="mbtn btn btn-primary">Send New Supplier Data</button>
    </div>
    </form>

    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
  <!-- Bootstrap core JavaScript -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" ></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>
  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" ></script>
  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
    $(document).ready(function () {
  $('#customerstable').DataTable();
  $('.dataTables_length').addClass('bs-select');
});

$(document).ready(function() {
    $("#searchdata").click(function(){
            $('#editSupplierModal').modal({"backdrop": "static"});
    });
});
  </script>

</body>

</html>

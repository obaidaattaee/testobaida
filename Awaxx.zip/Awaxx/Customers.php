<?php
require_once 'controllers/authController.php';
require_once 'controllers/customersMgmt.php';
    session_start();

if(!isset($_SESSION['id'])){
  header('location: Login.php');
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Awaxx Technologies - Customers Management System</title>

  <!-- Bootstrap core CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
  <!--===============================================================================================-->
  <script src="https://kit.fontawesome.com/4f8eb25e26.js" crossorigin="anonymous"></script>

  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">

  <!-- Custom styles for this template -->
  <link href="Style/Dashboard/simple-sidebar.css" rel="stylesheet">
  <link href="Style/Dashboard/dashstyle.css" rel="stylesheet">


</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Awaxx Technologies</div>
      <div class="list-group list-group-flush">
        <a href="Dashboard.php" class="item list-group-item list-group-item-action"><span class="fa fa-dashboard"></span>  &nbsp;Dashboard</a>
        <a href="Sales.php" class="item list-group-item list-group-item-action"><span class="fas fa-cash-register"></span>  &nbsp;Sales Transactions</a>
        <a href="Products.php" class="item list-group-item list-group-item-action"><span class="fa fa-industry"></span>  &nbsp;Products Inventory</a>
        <a href="Purchases.php" class="item list-group-item list-group-item-action"><span class="fa fa-shopping-bag"></span> &nbsp;Purchases Management</a>
        <a href="Expenses.php" class="item list-group-item list-group-item-action"><span class="fas fa-wallet"></span> &nbsp;Expenses Management</a>
        <a href="Accounts.php" class="item list-group-item list-group-item-action"><span class="fas fa-file-alt	"></span> &nbsp;Accounts Management</a>
        <a href="Customers.php" class="item-active list-group-item list-group-item-action"><span class="fas fa-handshake"></span>&nbsp;Customers Management</a>
        <a href="Suppliers.php" class="item list-group-item list-group-item-action"><span class="fas fa-truck-moving"></span>  &nbsp;Suppliers Management</a>
        <a href="Employee.php" class="item list-group-item list-group-item-action"><span class="fas fa-user-tie"></span>  &nbsp;Employees Management</a>
        <a href="Users.php" class="item list-group-item list-group-item-action"><span class="fas fa-portrait"></span> &nbsp;Users Management</a>
        <a href="Profile.php" class="item list-group-item list-group-item-action"><span class="fas fa-address-card"></span>  &nbsp;Profile Settings</a>
        <a href="Dashboard.php?logout=1" class="logout item list-group-item list-group-item-action item"><span class="fas fa-sign-out-alt"></span> &nbsp;Logout</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
      <button style="width: 5rem;" class="tbtn btn btn-primary" id="menu-toggle"><span><i class="fa fa-reorder"></i></span></button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Customers Management <span class="sr-only">(current)</span></a>
            </li>
            <li style=" color:#00b0d8; " class="nav-item nav-link">How's it going,   <?php echo $_SESSION['username']; ?> </li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">
        <h1 class="mt-4"> <span class="fa fa-group"></span>  &nbsp;Customers Management</h1>
        <br>

        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
          <?php foreach ($errors as $error): ?>

          <li> <?php echo $error; ?> </li>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if(count($success) > 0): ?>
        <div class="alert alert-success">
          <?php foreach ($success as $succeses): ?>

          <li> <?php echo $succeses; ?> </li>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div style="margin-left: 2px;" class="card info"  style="width: 21rem; height: 15rem;">
          <div class="card-body">
            <h2 class="card-title"><span class="fa fa-bar-chart"></span> &nbsp; Latest Added Customers</h1><br>
              <button type="button" style="margin: 20px 50px; " id="#showaddcustomermodal" class="mtbtn tbtn btn btn-primary" data-toggle="modal" data-target="#addCustomerModal"> Add new Customer </button>
              <button type="button" style="margin: 20px 50px; " id="#showeditcustomermodal" class="mtbtn1 tbtn btn btn-primary" data-toggle="modal" data-target="#editCustomerModal"> Edit / Delete Customer </button>
              <div class="table-responsive">
        <table style="text-align: center; margin-top:2%;" id="customerstable" class="table cell-border order-column table-hover row-border">
  <thead>
    <tr>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Customer ID</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Name</th>
      <th style="background-color: #00b0d8; color: #fff;"scope="col">Email</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Phone</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Address</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Purchases Value</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Contact Mode</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">First Time Added</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Customer Interests</th>
    </tr>
  </thead>
  <tbody>

    <?php
        $sqlcd = "SELECT CustomerID, Name, Email, Phone, Address, CustomerValue, ContactM, Dateadded, HI FROM customers  ORDER BY `customers`.`Dateadded` DESC";
        $resultcd = $conn->query($sqlcd);
        if ($resultcd->num_rows > 0) {
        // output data of each row
        while($row = $resultcd->fetch_assoc()) {
        echo "<tr>
        <th>" . $row['CustomerID']. "</th>
        <th>" . $row["Name"]. "</th>
        <td>" . $row["Email"] . " </td>
        <td>" . $row["Phone"] . " </td>
        <td>" . $row["Address"]. "</td>
        <td>" . $row["CustomerValue"]. "</td>
        <td>" . $row["ContactM"]. "</td>
        <td>" . $row["Dateadded"]. "</td>
        <td>" . $row["HI"]. "</td>
        </tr>";
        }


        $conn->close();
      }
         ?>

  </tbody>
</table>
</div>

    </div>
  </div>
    <div class="modal fade" id="addCustomerModal" tabindex="-1" role="dialog"   aria-labelledby="addCustomerLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content" style="width: 41rem; margin-left: -15%;">
          <div class="modal-header">
            <h5 class=" modal-title" id="addCustomerLabel"></h5>
            <button type="button" class="close" style="cursor: pointer !important;" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body" >
            <div class="card" style="width: 39rem;" >
              <div class="card-header text-center">
                <strong> Record a New Customer Data </strong>
              </div>
              <div class="card-body">
            <h5 class="card-title text-center">Add a new Customer</h5>
            <p class="card-text text-center">Fill the fileds below to add a new Customer.</p>
            <br>
            <form method="POST" action="Customers.php?addcustomer">
                <fieldset>
                  <legend>Communication Details</legend>
                  <hr>
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="customername">Customer Name</label>
                    <input type="text" class="form-control" name="CustomerName" id="customername" required placeholder="Customer Name">
                  </div>
                  <div class="form-group col-md-6">
                    <label for="custemail">Email Address</label>
                    <input type="email" class="form-control" name="CustomerEmail" id="custemail" placeholder="Customer Email Address">
                  </div>
                  <div class="form-group col-md-6">
                    <label for="custphone">Phone Number</label>
                    <input type="tel" class="form-control" name="CustomerPhone" id="custphone" placeholder="Customer Phone Number">
                  </div>
                </div>
                  <div class="form-row">
                <div class="form-group col-md-6 ">
                  <label for="custaddr">Physical Address</label>
                    <input type="text" class="form-control" name="CustomerAddress" id="custaddr" placeholder="Customer Physical Address">
                </div>
                <div class="form-group col-md-6">
                  <label for="contmod">Mode of Contact</label>
                  <select name="CustomerContactMode" id="contmod" class="form-control">
                    <option selected>Choose Mode of Contact</option>
                    <option value="Email">Email</option>
                    <option value="Phone" > Phone</option>
                    <option value="IM">IM </option>
                  </select>
                </div>
              </div>
              </fieldset>
              <hr>
              <fieldset>
                <legend>Profile Details</legend>
                <hr>
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="custbd"> Customer Birthday </label>
                    <input type="date" name="CustomerBdate" class="form-control" id="custbd" >
                  </div>

                  <div class="form-group col-md-6">
                    <label for="custhobbies">Hobbies & Interests</label>
                    <input type="text" class="form-control" name="CustomerHI" id="custhobbies" placeholder="Customer Hobbies & Interests">
                  </div>
                </div>
                  <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputTech">Technology usage levels</label>
                    <select  name="CustomerTechL" id="inputTech" class="form-control">
                      <option selected>Choose Technology level</option>
                      <option value="High" >High</option>
                      <option value="Moderate" >Moderate</option>
                      <option value="Low">Low</option>
                    </select>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="inpuIncome">Income levels</label>
                    <select name="CustomerIncomeL" id="inpuIncome" class="form-control">
                      <option selected>Choose Income Level</option>
                      <option value="High">High</option>
                      <option value="Moderate">Moderate</option>
                      <option value="Low">Low</option>
                    </select>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="inputFeel"> Interaction towards us </label>
                    <select name="CustomerInteraction" id="inputFeel" class="form-control">
                      <option selected>Choose Interaction</option>
                      <option value="Positive">Positive</option>
                      <option value="Negative">Negative</option>
                    </select>
                  </div>

              </div>
            </fieldset>

          <div class="card-footer text-center text-muted">
            <?php echo date("Y-m-d H:i:s"); ?>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="mbtn btn btn-secondary" data-dismiss="modal">Close</button>
        <button  type="submit" name="addCustomer-btn" class="mbtn btn btn-primary">Add Customer</button>
      </div>
      </form>

    </div>
  </div>
</div>
</div>

  <!-- /#wrapper -->
  <div class="modal fade" id="editCustomerModal" tabindex="-1" role="dialog" aria-labelledby="editCustomerLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content" style="width: 41rem; margin-left: -15%;">
        <div class="modal-header">
          <h5 class=" modal-title" id="editCustomerLabel"></h5>
          <button type="button" class="close" style="cursor: pointer !important;" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" >
          <div class="card" style="width: 39rem;" >
            <div class="card-header text-center">
              <strong> Record Existing Customer Data </strong>
            </div>
            <div class="card-body">
          <h5 class="card-title text-center">Edit Exiting Customer</h5>
          <p class="card-text text-center">Search for customer by customer ID then edit existing customer data by edit the fileds below. to delete the customer just search forcustomer by customer ID  then click on delete button.</p>
          <br>
          <form method="POST" action="Customers.php?editcustomer">
            <div class="form-row">
                <div class="form-group col-md-8">
                  <label for="customerid">Customer ID</label>
                  <input type="text" class="form-control" name="ecustomerid" id="customerid" required value="<?php echo $_SESSION['cCode']; ?>" placeholder="Input Customer ID You are looking for">
                </div><!-- Seaching -->
                <div class="form-group col-md-3">
                  <button type="submit" style="width:9rem; margin-top: 32px;" name="searchCustomer-btn" id="searchdata" class="tbtn btn btn-primary btn-search"> Search  </button>
                </div>
            </div>
              <fieldset>
                <legend>Communication Details</legend>
                <hr>
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="eccustomername">Customer Name</label>
                  <input type="text" class="form-control" name="eCustomerName" id="eccustomername" placeholder="Customer Name" value="<?php echo $_SESSION['cName']; ?>" >
                </div>
                <div class="form-group col-md-6">
                  <label for="eccustemail">Email Address</label>
                  <input type="email" class="form-control" name="eCustomerEmail" id="eccustemail" placeholder="Customer Email Address" value="<?php echo $_SESSION['cEmail']; ?>">
                </div>
                <div class="form-group col-md-6">
                  <label for="eccustphone">Phone Number</label>
                  <input type="tel" class="form-control" name="eCustomerPhone" id="eccustphone" placeholder="Customer Phone Number" value="<?php echo $_SESSION['cPhone']; ?>" >
                </div>
              </div>
                <div class="form-row">
              <div class="form-group col-md-6 ">
                <label for="eccustaddr">Physical Address</label>
                  <input type="text" class="form-control" name="eCustomerAddress" id="eccustaddr" placeholder="Customer Physical Address" value="<?php echo $_SESSION['cAddress']; ?>" >
              </div>
              <div class="form-group col-md-6">
                <label for="eccontmod">Mode of Contact</label>
                <select name="eCustomerContactMode" id="eccontmod" class="form-control">
                  <option selected>Choose Mode of Contact</option>
                  <option value="Email" <?php if($_SESSION['cContactM']=="Email") echo ' selected'; ?>>Email</option>
                  <option value="Phone" <?php if($_SESSION['cContactM']=="Phone") echo ' selected'; ?>>Phone</option>
                  <option value="IM" <?php if($_SESSION['cContactM']=="IM") echo ' selected'; ?>>IM </option>
                </select>
              </div>
            </div>
            </fieldset>
            <hr>
            <fieldset>
              <legend>Profile Details</legend>
              <hr>
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="eccustbd"> Customer Birthday </label>
                  <input type="date" name="eCustomerBdate" class="form-control"  id="eccustbd" value="<?php echo $_SESSION['cBdate']; ?>" >
                </div>

                <div class="form-group col-md-6">
                  <label for="ecusthobbies">Hobbies & Interests</label>
                  <input type="text" class="form-control" name="eCustomerHI" id="ecusthobbies" placeholder="Customer Hobbies & Interests" value="<?php echo $_SESSION['cHI']; ?>">
                </div>
              </div>
                <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="ecinputTech">Technology usage levels</label>
                  <select  name="eCustomerTechL" id="ecinputTech" class="form-control">
                    <option selected>Choose Technology level</option>
                    <option value="High" <?php if($_SESSION['cTechUseL']=="High") echo ' selected'; ?>>High</option>
                    <option value="Moderate" <?php if($_SESSION['cTechUseL']=="Moderate") echo ' selected'; ?> >Moderate</option>
                    <option value="Low" <?php if($_SESSION['cTechUseL']=="Low") echo ' selected'; ?> >Low</option>
                  </select>
                </div>
                <div class="form-group col-md-6">
                  <label for="ecinpuIncome">Income levels</label>
                  <select name="eCustomerIncomeL" id="ecinpuIncome" class="form-control">
                    <option selected>Choose Income Level</option>
                    <option value="High" <?php if($_SESSION['cIncomeL']=="High") echo ' selected'; ?> >High</option>
                    <option value="Moderate" <?php if($_SESSION['cIncomeL']=="Moderate") echo ' selected'; ?> >Moderate</option>
                    <option value="Low" <?php if($_SESSION['cIncomeL']=="Low") echo ' selected'; ?>>Low</option>
                  </select>
                </div>
                <div class="form-group col-md-6">
                  <label for="ecinputFeel"> Interaction towards us </label>
                  <select name="eCustomerInteraction" id="ecinputFeel" class="form-control">
                    <option selected>Choose Interaction</option>
                    <option value="Positive" <?php if($_SESSION['cInteraction']=="Positive") echo ' selected'; ?>>Positive</option>
                    <option value="Negative" <?php if($_SESSION['cInteraction']=="Negative") echo ' selected'; ?>>Negative</option>
                  </select>
                </div>

            </div>
          </fieldset>

        <div class="card-footer text-center text-muted">
          <?php echo date("Y-m-d H:i:s"); ?>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="mbtn btn btn-secondary" data-dismiss="modal">Close</button>
      <button type="submit" name="deleteCustomer-btn" class="mbtn btn btn-primary">Delete Customer</button>
      <button  type="submit" name="editCustomer-btn" class="mbtn btn btn-primary">Send New Customer Data</button>
    </div>
    </form>

  </div>
</div>
</div>
</div>
</div>
  <!-- Bootstrap core JavaScript -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" ></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>
  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" ></script>
  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
    $(document).ready(function () {
  $('#customerstable').DataTable();
  $('.dataTables_length').addClass('bs-select');
});

  </script>

</body>

</html>

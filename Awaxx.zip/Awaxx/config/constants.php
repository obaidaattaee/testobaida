<?php

define('DB_HOST', '127.0.0.1');
define('DB_USER', 'obaida');
define('DB_PASS', 'obaida');
define('DB_NAME','ajax');
//define('EMAIL','awaxx.technologies@gmail.com');
//define('PASSWORD','0569075817bH');
?>

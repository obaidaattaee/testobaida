<?php
require 'config/db.php';


if(isset($_POST['eitemcode'])){
  
    $sitemcode = $_POST['eitemcode'];
    $searchProduct = "SELECT * FROM products Where Code = '$sitemcode' ";
  
    $searchP = mysqli_query($conn, $searchProduct);
    if(mysqli_num_rows($searchP) > 0){
  
      $sprdoucts = mysqli_fetch_assoc($searchP);
       
       $_SESSION['sCode'] = $sprdoucts['Code'];
       $_SESSION['sName'] = $sprdoucts['Name'];
       $_SESSION['sCost'] = $sprdoucts['Cost'];
       $_SESSION['sPrice'] = $sprdoucts['Price'];
       $_SESSION['sQuantity'] = $sprdoucts['Quantity'];
       $_SESSION['sSupplierID'] = $sprdoucts['SupplierID'];
       $success['found'] = "The item you are looking for has been found successfully";
        echo json_encode($_SESSION);
    }else{
          $errors['notfound'] = "The item you are searching for by the code <b>does not exist in our records</b>";
    }
  }
let myChart1 = document.getElementById("inexp").getContext('2d');
let chart1 = new Chart(myChart1, {
  type: 'doughnut',
  data: {
        labels: ['Income','Expenses'],
        datasets: [{
          data: [1356, 543], backgroundColor:['#36caab', '#b0413e']
        }]
  },
  options: {
    title: {
      text: "Income Vs Expense",
      display: true
    }
  }
});

let myChart2 = document.getElementById("c_ranks").getContext('2d');
let chart2 = new Chart(myChart2, {

  type: 'bar',
  data: {
    labels: ['Ahmed','Ali','Khaled','Sameer','Mohammed'],
    datasets: [{
      data: [725, 452, 893, 125, 189], backgroundColor:['#49a9ea', '#36caab', '#34495e', '#b370cf','#b0413e' ]
    }]
  },
  options: {
    title: {
      text: "Value of Customers", display: true,
    },
    legend: {
      display: false
    }
  }
});

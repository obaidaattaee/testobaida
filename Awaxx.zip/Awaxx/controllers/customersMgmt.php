<?php

require 'config/db.php';

$errors = array();
$success = array();


if(isset($_POST['addCustomer-btn'])){

  $Cname = $_POST['CustomerName'];
  $Cemail = $_POST['CustomerEmail'];
  $Cphone = $_POST['CustomerPhone'];
  $Caddr = $_POST['CustomerAddress'];
  $Ccontactm = $_POST['CustomerContactMode'];
  $Cbdate = $_POST['CustomerBdate'];
  $Chi = $_POST['CustomerHI'];
  $Ctechuse = $_POST['CustomerTechL'];
  $Cincomel = $_POST['CustomerIncomeL'];
  $Cinter = $_POST['CustomerInteraction'];

$addCustomerQuery = "INSERT INTO customers (
  Name, Email, Phone, Address, ContactM, Bdate, HI, TechUseL, IncomeL, Interaction, Dateadded)
  VALUES('$Cname','$Cemail', '$Cphone','$Caddr','$Ccontactm','$Cbdate', '$Chi', '$Ctechuse','$Cincomel','$Cinter', now() )";


  if($addC = mysqli_query($conn, $addCustomerQuery)){
    $success['cadded'] = "Customer added successfully";
  }else{
    $errors['notcadded'] = "You encountered some errors with the server in adding the customer, pleases contact you system administrator ";
  }

}

if(isset($_POST['searchCustomer-btn'])){
  $ecustomerid = $_POST['ecustomerid'];
  $searchCustomer = "SELECT * FROM customers Where CustomerID = '$ecustomerid' ";

  $searchC = mysqli_query($conn, $searchCustomer);
  if(mysqli_num_rows($searchC) > 0){

    $ecustomers = mysqli_fetch_assoc($searchC);

    $_SESSION['cCode'] = $ecustomers['CustomerID'];
    $_SESSION['cName'] = $ecustomers['Name'];
    $_SESSION['cEmail'] = $ecustomers['Email'];
    $_SESSION['cPhone'] = $ecustomers['Phone'];
    $_SESSION['cAddress'] = $ecustomers['Address'];
    $_SESSION['cContactM'] = $ecustomers['ContactM'];
    $_SESSION['cBdate'] = $ecustomers['Bdate'];
    $_SESSION['cHI'] = $ecustomers['HI'];
    $_SESSION['cTechUseL'] = $ecustomers['TechUseL'];
    $_SESSION['cIncomeL'] = $ecustomers['IncomeL'];
    $_SESSION['cInteraction'] = $ecustomers['Interaction'];


    $success['found'] = "The customer you are looking for has been found successfully";
  }else{
        $errors['notfound'] = "The customer you are searching for by the ID <b>does not exist in our records</b>";
  }
}

if(isset($_POST['deleteCustomer-btn'])){
   $dc_code = $_POST['ecustomerid'];
   $searchec =  "SELECT * FROM customers Where CustomerID = '$dc_code' ";
   $vsearchec  = mysqli_query($conn, $searchec);
     if(mysqli_num_rows($vsearchec) > 0){
   $deleteCustomer = "DELETE FROM customers WHERE CustomerID='$dc_code'";
   if($delC = mysqli_query($conn, $deleteCustomer)){

   unset($_SESSION['cCode']);
   unset($_SESSION['cName']);
   unset($_SESSION['cEmail']);
   unset($_SESSION['cPhone']);
   unset($_SESSION['cAddress']);
   unset($_SESSION['cContactM']);
   unset($_SESSION['cBdate']);
   unset($_SESSION['cHI']);
   unset($_SESSION['cTechUseL']);
   unset($_SESSION['cIncomeL']);
   unset($_SESSION['cInteraction']);

   $success['customerdeleted'] = "Customer data erased successfully" ;
 }else{
  $errors['notdeleted'] = "You encountered some errors with the server in deleting customer data , please contact your system administrator";}
  }else{
      $errors['delnotexists'] = "You are trying to delete data for a <b>non-existent customer</b>";
  }
}


if (isset($_POST['editCustomer-btn'])){
  $ec_code =  $_POST['ecustomerid'];
  $eCname = $_POST['eCustomerName'];
  $eCemail = $_POST['eCustomerEmail'];
  $eCphone = $_POST['eCustomerPhone'];
  $eCaddr = $_POST['eCustomerAddress'];
  $eCcontactm = $_POST['eCustomerContactMode'];
  $eCbdate = $_POST['eCustomerBdate'];
  $eChi = $_POST['eCustomerHI'];
  $eCtechuse = $_POST['eCustomerTechL'];
  $eCincomel = $_POST['eCustomerIncomeL'];
  $eCinter = $_POST['eCustomerInteraction'];

  $ecsearch = "SELECT * FROM customers WHERE CustomerID = '$ec_code' ";
  $vecsearch = mysqli_query($conn, $ecsearch);

  if(mysqli_num_rows($vecsearch) > 0){

  $editCustomerQuery = "UPDATE customers SET Name='$eCname', Email='$eCemail',
   Phone='$eCphone',Address='$eCaddr',ContactM='$eCcontactm', Bdate='$eCbdate',
   HI='$eChi',TechUseL='$eCtechuse', IncomeL='$eCincomel',Interaction='$eCinter'
   WHERE CustomerID = '$ec_code' ";

   if($editC = mysqli_query($conn, $editCustomerQuery)){
     unset($_SESSION['cCode']);
     unset($_SESSION['cName']);
     unset($_SESSION['cEmail']);
     unset($_SESSION['cPhone']);
     unset($_SESSION['cAddress']);
     unset($_SESSION['cContactM']);
     unset($_SESSION['cBdate']);
     unset($_SESSION['cHI']);
     unset($_SESSION['cTechUseL']);
     unset($_SESSION['cIncomeL']);
     unset($_SESSION['cInteraction']);
     $success['customeredited'] = "Customer data edited successfully";
   }else{
     $errors['cnotedited'] = "You encountered some errors with the server in editing customer data, pleases contact you system administrator";
   }

 }else{
   $errors['ceditnotexists'] = "You are trying to modify data for a <b>non-existent customer</b>";
 }

}


 ?>

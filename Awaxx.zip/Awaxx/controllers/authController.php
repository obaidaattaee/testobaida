<?php

session_start();

require 'config/db.php';

$errors = array();
$username = "";
$email = "";


//Signup
if(isset($_POST['signup-btn'])){

	$username = $_POST['username'];
	$email = $_POST['email'];
	$passwordconf = $_POST['passwordconf'];


if (empty($username)) {
		$errors['username'] = "Username Required";
	}

	if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
		$errors['email'] = "Email Address is Invalid";
	}

	if (empty($email)) {
		$errors['email'] = "Email Required";
	}

	if (empty($_POST['password'])) {
		$errors['password'] = "Password Required";
	}

	if ($_POST['password'] !== $passwordconf){
		$errors['password'] = " Passwords Don't Match";
	}

	$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

//Check if Email Exists

	$emailQuery = "SELECT * FROM users WHERE Email=? LIMIT 1";
	$stmt = $conn->prepare($emailQuery);
	$stmt->bind_param('s', $email);
	$stmt->execute();
	$result = $stmt->get_result();
	$userCount = $result->num_rows;
	$stmt->close();
	if($userCount > 0){
		$errors['email'] = "Email Already Exists";
	}

	if(count($errors) === 0){

		$sql = "INSERT INTO users (Username, Email, Password) VALUES(?,?,?)";
		$stmt = $conn->prepare($sql);
		$stmt->bind_param('sss', $username, $email, $password);

		if($stmt->execute()){
			//Login success
			$user_id = $conn->insert_id;
			$_SESSION['id'] = $user_id;
			$_SESSION['username'] = $username;
			$_SESSION['email'] = $email;
			$_SESSION['phone'] = $user_id['Phone'];
			$_SESSION['address'] = $user_id['Address'];


			$_SESSION['message'] = "Login Successed";
			$_SESSION['alert-class'] = "alert-success";

			header('location: Dashboard.php');
			exit();
		}else{
			$errors['db_error'] = "Database Error: Failed to Sign Up ";

}


}

}

//Login

	if (isset($_POST['login-btn'])) {


    if (empty($_POST['username'])) {
        $errors['username'] = 'Username or email required';
    }
    if (empty($_POST['password'])) {
        $errors['password'] = 'Password required';
    }

		$username = $_POST['username'];
		$password = $_POST['password'];

    if (count($errors) === 0) {

        $query = "SELECT * FROM users WHERE Email=? OR Username=? LIMIT 1";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('ss', $username, $username);
      	$stmt->execute();
				if ($stmt->execute()) {
						$result = $stmt->get_result();
						$user = $result->fetch_assoc();

        if (password_verify($password, $user['Password'])) { // if password matches

								$_SESSION['id'] = $user['ID'];
								$_SESSION['username'] = $user['Username'];
								$_SESSION['email'] = $user['Email'];
								$_SESSION['phone'] = $user['Phone'];
								$_SESSION['address'] = $user['Address'];
								$_SESSION['message'] = "Login Successed";
								$_SESSION['alert-class'] = "alert-success";

								header('location: Dashboard.php');
                exit();

            }

						else { // if password does not match
                $errors['login_fail'] = "These credentials don't match our records.";
            }
					}else{
						$_SESSION['message'] = "Database error. Login failed!";
            $_SESSION['type'] = "alert-danger";
					}

    }
}
	//Logout

	if(isset($_GET['logout'])){
		session_destroy();
		unset($_SESSION['id']);
		unset($_SESSION['username']);
		unset($_SESSION['email']);
		header('location: Login.php');
		exit();
	}

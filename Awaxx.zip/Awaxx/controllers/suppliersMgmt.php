<?php

require 'config/db.php';

$errors = array();
$success = array();
if(isset($_POST['addSupplier-btn'])){

  $sname = $_POST['SupplierName'];
  $semail = $_POST['SupplierEmail'];
  $sphone = $_POST['SupplierPhone'];
  $saddress = $_POST['SupplierAddress'];
  $sconmod = $_POST['SupplierContactMode'];
  $sseg = $_POST['SupplierSegment'];

  $addSupplierQuery = "INSERT INTO suppliers (Name, Email, Phone, Address, Segment, SupplierCM, TimeAdded)
      VALUES('$sname', '$semail','$sphone' , '$saddress', '$sseg', '$sconmod', now() )";


        if($addS = mysqli_query($conn, $addSupplierQuery)){
          $success['sadded'] = "Supplier added successfully";
        }else{
          $errors['notsadded'] = "You encountered some errors with the server in adding the supplier, pleases contact you system administrator ";
        }

      }

      if(isset($_POST['searchSupplier-btn'])){
        $esupplierid = $_POST['esupplierid'];
        $searchSupplier = "SELECT * FROM suppliers Where SupplierID = '$esupplierid' ";

        $searchS = mysqli_query($conn, $searchSupplier);
        if(mysqli_num_rows($searchS) > 0){

          $esupplier = mysqli_fetch_assoc($searchS);

          $_SESSION['sID'] = $esupplier['SupplierID'];
          $_SESSION['sName'] = $esupplier['Name'];
          $_SESSION['sEmail'] = $esupplier['Email'];
          $_SESSION['sPhone'] = $esupplier['Phone'];
          $_SESSION['sAddress'] = $esupplier['Address'];
          $_SESSION['sContactM'] = $esupplier['SupplierCM'];
          $_SESSION['sSegment'] = $esupplier['Segment'];



          $success['found'] = "The supplier you are looking for has been found successfully";
        }else{
              $errors['notfound'] = "The supplier you are searching for by the ID <b>does not exist in our records</b>";
        }
      }

      if(isset($_POST['deleteSupplier-btn'])){
         $ds_code = $_POST['esupplierid'];
         $searches =  "SELECT * FROM suppliers Where SupplierID = '$ds_code' ";
         $vsearches  = mysqli_query($conn, $searches);
           if(mysqli_num_rows($vsearches) > 0){
         $deleteSupplier = "DELETE FROM suppliers WHERE SupplierID='$ds_code'";
         if($delS = mysqli_query($conn, $deleteSupplier)){

         unset($_SESSION['sID']);
         unset($_SESSION['sName']);
         unset($_SESSION['sEmail']);
         unset($_SESSION['sPhone']);
         unset($_SESSION['sAddress']);
         unset($_SESSION['sContactM']);
         unset($_SESSION['sSegment']);


         $success['supplierdeleted'] = "Supplier data erased successfully" ;
       }else{
        $errors['snotdeleted'] = "You encountered some errors with the server in deleting supplier data , please contact your system administrator";}
        }else{
            $errors['sdelnotexists'] = "You are trying to delete data for a <b>non-existent supplier</b>";
        }
      }


      if (isset($_POST['editSupplier-btn'])){
        $es_code =  $_POST['esupplierid'];
        $eSname = $_POST['eSupplierName'];
        $eSemail = $_POST['eSupplierEmail'];
        $eSphone = $_POST['eSupplierPhone'];
        $eSaddr = $_POST['eSupplierAddress'];
        $eScontactm = $_POST['eSupplierContactMode'];
        $eSSEG = $_POST['eSupplierSegment'];


        $essearch = "SELECT * FROM suppliers WHERE SupplierID = '$es_code' ";
        $vessearch = mysqli_query($conn, $essearch);

        if(mysqli_num_rows($vessearch) > 0){

        $editSupplierQuery = "UPDATE suppliers SET Name='$eSname', Email='$eSemail',
         Phone='$eSphone', Address='$eSaddr', Segment='$eSSEG', SupplierCM='$eScontactm'
         WHERE SupplierID = '$es_code' ";

         if($editS = mysqli_query($conn, $editSupplierQuery)){
           unset($_SESSION['sID']);
           unset($_SESSION['sName']);
           unset($_SESSION['sEmail']);
           unset($_SESSION['sPhone']);
           unset($_SESSION['sAddress']);
           unset($_SESSION['sContactM']);
           unset($_SESSION['sSegment']);

           $success['supplieredited'] = "Supplier data edited successfully";
         }else{
           $errors['snotedited'] = "You encountered some errors with the server in editing supplier data, pleases contact you system administrator";
         }

       }else{
         $errors['seditnotexists'] = "You are trying to modify data for a <b>non-existent supplier</b>";
       }

      }

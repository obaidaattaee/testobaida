 <?php

require 'config/db.php';

$errors = array();
$success = array();
if(isset($_POST['addProduct-btn'])){

  $icode = $_POST['itemcode'];
  $iname = $_POST['itemname'];
  $icost = $_POST['ucost'];
  $iprice = $_POST['uprice'];
  $iquan = $_POST['quan'];
  $isupp = $_POST['supplierid'];

  $addProductQuery = "INSERT INTO products (Code, Name, Cost, Price, Quantity, TransactionTime, SupplierID)
      VALUES('$icode', '$iname','$icost' , '$iprice', '$iquan',now(), '$isupp')";

  if($addP = mysqli_query($conn, $addProductQuery)){
  $success['added'] = "The Product Added Successfully";
  }else{
    $errors['notadded'] = "You encountered some errors with the server in adding the product, pleases contact you system administrator";
  }
}
if(isset($_POST['eitemcode'])){
  
  $sitemcode = $_POST['eitemcode'];
  $searchProduct = "SELECT * FROM products Where Code = '$sitemcode' ";

  $searchP = mysqli_query($conn, $searchProduct);
  if(mysqli_num_rows($searchP) > 0){

    $sprdoucts = mysqli_fetch_assoc($searchP);
     
     $_SESSION['sCode'] = $sprdoucts['Code'];
     $_SESSION['sName'] = $sprdoucts['Name'];
     $_SESSION['sCost'] = $sprdoucts['Cost'];
     $_SESSION['sPrice'] = $sprdoucts['Price'];
     $_SESSION['sQuantity'] = $sprdoucts['Quantity'];
     $_SESSION['sSupplierID'] = $sprdoucts['SupplierID'];
     $success['found'] = "The item you are looking for has been found successfully";

  }else{
        $errors['notfound'] = "The item you are searching for by the code <b>does not exist in our records</b>";
  }
}

if(isset($_POST['editProduct-btn'])){
  $eicode = $_POST['eitemcode'];
  $einame = $_POST['eitemname'];
  $eicost = $_POST['eucost'];
  $eiprice = $_POST['euprice'];
  $eiquan = $_POST['equan'];
  $eisupp = $_POST['esupplierid'];

  $vsearchProduct = "SELECT * FROM products Where Code = '$eicode' ";
  $vsearchP = mysqli_query($conn, $vsearchProduct);

  if(mysqli_num_rows($vsearchP) > 0){


      $editProductQuery = "UPDATE products SET Name = '$einame',
      Cost = '$eicost', Price = '$eiprice', Quantity = '$eiquan',
      SupplierID ='$eisupp' WHERE Code = '$eicode'";
      if($editP = mysqli_query($conn, $editProductQuery)){

    	unset($_SESSION['sCode']);
      unset($_SESSION['sName']);
  	  unset($_SESSION['sCost']);
      unset($_SESSION['sPrice']);
      unset($_SESSION['sQuantity']);
      unset($_SESSION['sSupplierID']);

      $success['edited'] = "The product data modified successfully" ;
      }
      else{
        $errors['notedited'] = "You encountered some errors with the server in editing the product, pleases contact you system administrator";
      }

    }else{
      $errors['editnotexists'] = "You are trying to modify data for an item <b>that does not exist</b>";
      }

}

if(isset($_POST['deleteProduct-btn'])){
   $dicode = $_POST['eitemcode'];
   $searchex =  "SELECT * FROM products Where Code = '$dicode' ";
   $vsearchex  = mysqli_query($conn, $searchex);
     if(mysqli_num_rows($vsearchex) > 0){
   $deleteProduct = "DELETE FROM products WHERE Code='$dicode'";
   if($delP = mysqli_query($conn, $deleteProduct)){

   unset($_SESSION['sCode']);
   unset($_SESSION['sName']);
   unset($_SESSION['sCost']);
   unset($_SESSION['sPrice']);
   unset($_SESSION['sQuantity']);
   unset($_SESSION['sSupplierID']);

   $success['deleted'] = "The product data erased successfully" ;
 }else{
  $errors['notdeleted'] = "You encountered some errors with the server in deleting the product, please contact your system administrator";}
  }else{
      $errors['delnotexists'] = "You are trying to delete data for an item <b>that does not exist</b>";
  }
}


<?php
require 'config/db.php';

$errors = array();
$success = array();


if(isset($_POST['changepass-btn'])){

  $oldPass= password_hash($_POST['oldprofilepass'], PASSWORD_DEFAULT);
  $newConfPass = $_POST['profilpassconf'];
  $newPass = password_hash($_POST['profilpass'], PASSWORD_DEFAULT);

  if($newPass != $oldPass){

    $CurrentPassQuery = "SELECT * FROM users WHERE ID = "$_SESSION['id']" ";
    $ChangePass= ($conn, $CurrentPassQuery);
    $passRowresult = mysqli_fetch_array($ChangePass);
    if ($oldPass == $passRowresult['Password']){
      $UpdatePassQuery = "UPDATE users SET Password = '$newPass' WHERE ID = "$_SESSION['id']" ";
    }


  }else{


  }



}






 ?>

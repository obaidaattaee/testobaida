<?php
require 'config/db.php';
$errors = array();
$success = array();

if(isset($_POST['spro-btn'])){
$sa_itemCode = $_POST['sitemcode'];

$searchItemQuery = "SELECT * FROM products WHERE Code='$sa_itemCode' ";

$saSearchExe = mysqli_query($conn, $searchItemQuery);

if(mysqli_num_rows($saSearchExe) > 0 ){

  $saitem = mysqli_fetch_assoc($saSearchExe);

  $_SESSION['pCode'] = $saitem['Code'];
  $_SESSION['pName'] = $saitem['Name'];
  $_SESSION['pCost'] = $saitem['Cost'];
  $_SESSION['pPrice'] = $saitem['Price'];
  $_SESSION['avQuantity'] = $saitem['Quantity'];
  $success['found'] = "The item you are looking for has been found successfully";

}else {
  $errors['notfound'] = "The item you are searching for by the code <b>does not exist in our records</b>";
  unset($_SESSION['pCode']);
  unset($_SESSION['pName']);
  unset($_SESSION['pCost']);
  unset($_SESSION['pPrice']);
  unset($_SESSION['avQuantity']);
}

}
if(isset($_POST['addtrans-btn'])){

  $productCode= $_SESSION['pCode'];
  $productQuantity= $_POST['productQuantity'];
  $productCost= $_POST['productCost'];
  $productPrice= $_POST['productPrice'];
  $productPayment= $_POST['productPayment'];
  $transDiscount = $_POST['transDiscount'];
  $productCustomer= $_POST['productCustomer'];
  $transAmount= ($productQuantity * $productPrice) - $transDiscount;
  $avQuantity = $_POST['avQuantity'];

  if($avQuantity >= 1 && $avQuantity >= $productQuantity){
    $addSalesTransactionQuery = "INSERT INTO
    sales (TransactionAmount, SoldQuantity, ModeOPay,DiscountAmount, TransactionTime, CustomerID,
    ItemCode) VALUES('$transAmount', '$productQuantity', '$productPayment','$transDiscount', now(),
    '$productCustomer', '$productCode')";

    if($addTransexe = mysqli_query($conn, $addSalesTransactionQuery)){

      $updateQuantityQuery = "UPDATE products SET Quantity = Quantity - '$productQuantity',
      UnitsSold = UnitsSold + '$productQuantity' WHERE Code= '$productCode' ";
      $updateQuantityQueryexe = mysqli_query($conn, $updateQuantityQuery);
      $UpdatePurshaseValue = "UPDATE customers SET CustomerValue = CustomerValue + '$transAmount'
      WHERE CustomerID = '$productCustomer' ";
      $UpdatePurshaseValueexe =  mysqli_query($conn, $UpdatePurshaseValue);





      $success['added'] = "Sales Transaction Added Successfully";
    }else{
      $errors['notadded'] = "You encountered some errors with the server in adding the product, pleases contact you system administrator ";
    }

  }else{
    $errors['quanerror'] = "Please check the quantity of the entered product";
  }

}






 ?>

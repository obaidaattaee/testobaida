<?php
  require_once 'controllers/authController.php';
  require_once 'controllers/salesMgmt.php';
    session_start();

if(!isset($_SESSION['id'])){
  header('location: Login.php');
  exit();

}

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Awaxx Technologies - Sales Management System</title>

  <!-- Bootstrap core CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">

  <!--===============================================================================================-->
  <script src="https://kit.fontawesome.com/4f8eb25e26.js" crossorigin="anonymous"></script>

  <link href="Style/Dashboard/dashstyle.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="Style/Dashboard/simple-sidebar.css" rel="stylesheet">


</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Awaxx Technologies</div>
      <div class="list-group list-group-flush">
        <a href="Dashboard.php" class="item list-group-item list-group-item-action"><span class="fa fa-dashboard"></span>  &nbsp;Dashboard</a>
        <a href="Sales.php" class="item-active list-group-item list-group-item-action"><span class="fas fa-cash-register"></span>  &nbsp;Sales Transactions</a>
        <a href="Products.php" class="item list-group-item list-group-item-action"><span class="fa fa-industry"></span>  &nbsp;Products Inventory</a>
        <a href="Purchases.php" class="item list-group-item list-group-item-action"><span class="fa fa-shopping-bag"></span> &nbsp;Purchases Management</a>
        <a href="Expenses.php" class="item list-group-item list-group-item-action"><span class="fas fa-wallet"></span> &nbsp;Expenses Management</a>
        <a href="Accounts.php" class="item list-group-item list-group-item-action"><span class="fas fa-file-alt	"></span> &nbsp;Accounts Management</a>
        <a href="Customers.php" class="item list-group-item list-group-item-action"><span class="fas fa-handshake"></span>&nbsp;Customers Management</a>
        <a href="Suppliers.php" class="item list-group-item list-group-item-action"><span class="fas fa-truck-moving"></span>  &nbsp;Suppliers Management</a>
        <a href="Employee.php" class="item list-group-item list-group-item-action"><span class="fas fa-user-tie"></span>  &nbsp;Employees Management</a>
        <a href="Users.php" class="item list-group-item list-group-item-action"><span class="fas fa-portrait"></span> &nbsp;Users Management</a>
        <a href="Profile.php" class="item list-group-item list-group-item-action"><span class="fas fa-address-card"></span>  &nbsp;Profile Settings</a>
        <a href="Dashboard.php?logout=1" class="logout item list-group-item list-group-item-action item"><span class="fas fa-sign-out-alt"></span> &nbsp;Logout</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
      <button style="width: 5rem;" class="tbtn btn btn-primary" id="menu-toggle"><span><i class="fa fa-reorder"></i></span></button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Sales Transaction <span class="sr-only">(current)</span></a>
            </li>
            <li style=" color:#00b0d8;" class="nav-item nav-link">How's it going, <?php echo $_SESSION['username']; ?></li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">

        <h1 class="mt-4"><span class="fas fa-cash-register"></span> &nbsp;Sales Transactions</h1>
        <br>
        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
          <?php foreach ($errors as $error): ?>

          <li> <?php echo $error; ?> </li>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if(count($success) > 0): ?>
        <div class="alert alert-success">
          <?php foreach ($success as $succeses): ?>

          <li> <?php echo $succeses; ?> </li>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>


        <div style="margin-left: 2px;" class="card info"  style="width: 21rem; height: 15rem;">
          <div class="card-body">
            <h2 class="card-title"><span class="fa fa-bar-chart"></span> &nbsp; Latest Added Sales Transaction</h1><br>
              <button type="button" style="margin: 20px 20px 30px 20px;  width: 15rem;" id="#showaddtransactionmodal" class="mtbtn tbtn btn btn-primary" data-toggle="modal" data-target="#addTransactionModal"> Add Sales Transaction </button>
              <button type="button" style="margin: 20px 20px 30px 60px;  width: 15rem;" id="#showedittransactionmodal" class="mtbtn tbtn btn btn-primary" data-toggle="modal" data-target="#editSalesModal"> Edit / Delete Transaction </button>
              <div class="table-responsive">
        <table style="text-align: center; margin-top:2%;" id="salestable" class="table cell-border order-column table-hover row-border">
  <thead>
    <tr>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">#</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Item Code</th>
      <th style="background-color: #00b0d8; color: #fff;"scope="col">Cumulative Amount</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Sold Quantity</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Discount Amount</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Mode of Payment</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Customer ID</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Transaction Time</th>
    </tr>
  </thead>
  <tbody>

    <?php
        $sqlcd = "SELECT TransactionID, ItemCode, TransactionAmount, SoldQuantity,DiscountAmount, ModeOPay, CustomerID, TransactionTime FROM sales ORDER BY `sales`.`TransactionTime` DESC";
        $resultcd = $conn->query($sqlcd);
        if ($resultcd->num_rows > 0) {
        // output data of each row
        while($row = $resultcd->fetch_assoc()) {
        echo "<tr>
        <th>" . $row['TransactionID']. "</th>
        <th>" . $row["ItemCode"]. "</th>
        <td>" . $row["TransactionAmount"] . " </td>
        <td>" . $row["SoldQuantity"] . " </td>
        <td>" . $row["DiscountAmount"] . " </td>
        <td>" . $row["ModeOPay"]. "</td>
        <td>" . $row["CustomerID"]. "</td>
        <td>" . $row["TransactionTime"]. "</td>

        </tr>";
        }


        $conn->close();
      }
         ?>

  </tbody>
  </table>
  </div>
  </div>
  <div class="modal fade" id="addTransactionModal" tabindex="-1" role="dialog"   aria-labelledby="AddTransactionLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content" style="width: 41rem; margin-left: -15%;">
        <div class="modal-header">
          <h5 class=" modal-title" id="AddTransactionLabel"></h5>
          <button type="button" class="close" style="cursor: pointer !important;" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" >
            <div class="card">
              <div class="card-header text-center">
                <strong>Record Sales Transaction</strong>
              </div>
              <div class="card-body">
                <h5 class="card-title text-center">Add a new Transaction</h5>
                <p class="card-text text-center">Fill the fileds below to add sales transaction.</p>
                <br>
                <form name="search_form" method="POST" action="Sales.php?searchitem">
                    <div class="form-row">
                      <div class="form-group col-md-6">
                        <label for="itemcode">Item Code</label>
                        <input type="text" class="form-control" id="itemcode" name="sitemcode" value="<?php echo $_SESSION['pCode']; ?>" required autocomplete="true" autofocus placeholder="Input Product Code">
                      </div>
                      <div style=" margin-top: 32px; display:inline;" class="form-group">
                        <button style="width: 6rem;" type="submit" name="spro-btn" Onclick='ajax();' class="tbtn btn btn-dark"> Search</button>
                      </div>
                    </div>
                    <hr>
                  </form>

                    <form  name="salesform"  method="POST" action"Sales.php?AddTransaction" onkeyup="calculate()" >
                      <div class="form-row">
                      <div class="form-group col-md-6">
                        <label for="drate">Product Name</label>
                        <input type="text" class="form-control" value="<?php echo $_SESSION['pName']; ?>" id="drate" readonly placeholder="Product Name">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="quantity">Sold Quantity</label>
                        <input type="number" min="1" class="form-control" name="productQuantity" id="quantity" required placeholder="Input Sold Product Quantity">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="dvalue">Discount Value</label>
                        <input type="number" min="0" name="transDiscount" class="form-control" id="dvalue"  placeholder="Discount Value">
                      </div>
                    </div>

                    <div class="form-row">
                      <div class="form-group col-md-6">
                        <label for="pquan">Available Quantity</label>
                        <input type="number" min="0" class="form-control" name="avQuantity" id="pquan" value="<?php echo $_SESSION['avQuantity']; ?>"  readonly required placeholder="Available Product Quantity">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="icost">Item Cost</label>
                        <input type="number" min="1" class="form-control" name="productCost" id="icost" value="<?php echo $_SESSION['pCost']; ?>"  readonly required placeholder="Cost/Item">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="iprice">Item Price</label>
                        <input type="number" min="1" class="form-control" name="productPrice" id="iprice" value="<?php echo $_SESSION['pPrice']; ?>"  readonly required placeholder="Price/Item">
                      </div>
                    </div>
                    <div class="form-row">
                      <div class="form-group col-md-6">
                        <label for="camount"> Cumulative Amount </label>
                        <input type="number" min="0" class="form-control" name="camount" id="camount" readonly placeholder="Cumulative Amount">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="inputMode">Mode of Payment</label>
                        <select id="inputMode" name="productPayment" required class="form-control">
                          <option selected value="Cash" >Cash</option>
                          <option  value="Account Receivable">Account Receivable</option>
                          <option  value="Cheques">Cheques</option>
                          <option  value="Credit card">Credit card</option>
                        </select>
                      </div>
                      <div class="form-group col-md-6">
                        <label for="inputCid">Customer ID</label>
                        <input type="number" min="1" name="productCustomer" class="form-control" id="inputCid">
                      </div>
                    </div>

              </div>
              <div class="card-footer text-center text-muted">
                <?php echo date("Y-m-d H:i:s"); ?>
              </div>
            </div>
          </div>
          <div style="margin-top: -30px;" class="modal-footer">
            <button type="button" class="mbtn btn btn-secondary" data-dismiss="modal">Close</button>
            <button  type="submit" name="addtrans-btn" class="mbtn btn btn-primary">Add Sales Transaction</button>
          </div>
          </form>


        </div>
    </div>
    <!-- /#page-content-wrapper -->
  </div>
  <div class="modal fade" id="editSalesModal" tabindex="-1" role="dialog" aria-labelledby="editSalesLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content" style="width: 41rem; margin-left: -15%;">
        <div class="modal-header">
          <h5 class=" modal-title" id="editSalesLabel"></h5>
          <button type="button" class="close" style="cursor: pointer !important;" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" >
          <div class="card" style="width: 39rem;" >
            <div class="card-header text-center">
              <strong> Edit Existing Sales Transaction </strong>
            </div>
            <div class="card-body">
          <h5 class="card-title text-center">Edit Exiting  Sales Transaction</h5>
          <p class="card-text text-center">Search for transaction by Transaction ID then edit existing transaction data by edit the fileds below. to delete the transaction just search for transaction by Transaction ID  then click on delete button.</p>
          <br>
          <form name="search_form" method="POST" action="Sales.php?searchitem">
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="etransid">Transaction ID</label>
                  <input type="text" class="form-control" id="etransid" name="etransid" value="<?php echo $_SESSION['tId']; ?>" required autocomplete="true" autofocus placeholder="Input Transaction ID">
                </div>
                <div style=" margin-top: 32px; display:inline;" class="form-group">
                  <button style="width: 6rem;" type="submit" name="stra-btn" Onclick='ajax();' class="tbtn btn btn-primary btn-search"> Search</button>
                </div>
              </div>
              <hr>
            </form>

              <form  name="salesform"  method="POST" action"Sales.php?AddTransaction" onkeyup="calculate()" >
                <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="drate">Product Name</label>
                  <input type="text" class="form-control" value="<?php echo $_SESSION['epName']; ?>" id="drate" readonly placeholder="Sold Product Name">
                </div>
                <div class="form-group col-md-6">
                  <label for="equantity">Sold Quantity</label>
                  <input type="number" min="1" class="form-control" name="eproductQuantity" id="equantity" required placeholder="Sold Quantity">
                </div>
                <div class="form-group col-md-6">
                  <label for="devalue">Discount Value</label>
                  <input type="number" min="0" name="etransDiscount" class="form-control" id="edvalue"  placeholder="Discount Value">
                </div>
              </div>

              <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="epquan">Available Quantity</label>
                  <input type="number" min="0" class="form-control" name="eavQuantity" id="epquan" value="<?php echo $_SESSION['eavQuantity']; ?>"  readonly required placeholder="Available Product Quantity">
                </div>
                <div class="form-group col-md-6">
                  <label for="eicost">Item Cost</label>
                  <input type="number" min="1" class="form-control" name="eproductCost" id="eicost" value="<?php echo $_SESSION['epCost']; ?>"  readonly required placeholder="Cost/Item">
                </div>
                <div class="form-group col-md-6">
                  <label for="eiprice">Item Price</label>
                  <input type="number" min="1" class="form-control" name="eproductPrice" id="eiprice" value="<?php echo $_SESSION['epPrice']; ?>"  readonly required placeholder="Price/Item">
                </div>
              </div>
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="ecamount"> Cumulative Amount </label>
                  <input type="number" min="0" class="form-control" name="ecamount" id="ecamount" readonly placeholder="Cumulative Amount">
                </div>
                <div class="form-group col-md-6">
                  <label for="einputMode">Mode of Payment</label>
                  <select id="einputMode" name="eproductPayment" required class="form-control">
                    <option selected value="Cash" >Cash</option>
                    <option  value="Account Receivable">Account Receivable</option>
                    <option  value="Cheques">Cheques</option>
                    <option  value="Credit card">Credit card</option>
                  </select>
                </div>
                <div class="form-group col-md-6">
                  <label for="einputCid">Customer ID</label>
                  <input type="number" min="1" name="eproductCustomer" class="form-control" id="einputCid">
                </div>
              </div>

        </div>
        <div class="card-footer text-center text-muted">
          <?php echo date("Y-m-d H:i:s"); ?>
        </div>
      </div>
    </div>
    <div style="margin-top: -30px;" class="modal-footer">
      <button type="button" class="mbtn btn btn-secondary" data-dismiss="modal">Close</button>
      <button  type="submit" name="edittrans-btn" class="mbtn btn btn-primary">Edit Sales Transaction</button>
    </div>
    </form>


    </div>
  </div>
</div>
</div>
</div>

  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" ></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" ></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>
  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" ></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });

    var form = document.forms.salesform, dis = form.transDiscount,
        qty = form.productQuantity,
        cost = form.productPrice,
        output = form.camount;

    window.calculate = function () {
        var q = parseInt(qty.value, 10) || 0,
            c = parseFloat(cost.value) || 0;
            d =  parseFloat(dis.value) || 0;
            z = (c * q) - d;
            if(z > 0){
        output.value = (c * q) - d;
      }else{
        output.value = 0;
      }
    };
  $(document).ready(function () {
    $('#salestable').DataTable();
    $('.dataTables_length').addClass('bs-select');
  });
  $('#salestable').dataTable({
    'iDisplayLength': 50
  });
/*
  function ajax()

  {

  var xmlHttp;
  alert("ajax");

  xmlHttp=new XMLHttpRequest();


  xmlHttp.onreadystatechange=function(){


  if(xmlHttp.readyState==4  && this.status == 200){

  document.getElementById("itemcode").innerHTML = xmlHttp.responseText;

  }

  }

  xmlHttp.open("POST","Sales.php?searchitem="+document.search_form.sitemcode.value,true);

  xmlHttp.send();

} */

  </script>



</body>

</html>

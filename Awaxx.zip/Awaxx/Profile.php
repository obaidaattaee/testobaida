<?php
require_once 'controllers/authController.php';
    session_start();

if(!isset($_SESSION['id'])){
  header('location: Login.php');
  exit();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Awaxx Technologies - Profile Settings </title>

  <!-- Bootstrap core CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  <!--===============================================================================================-->
  <script src="https://kit.fontawesome.com/4f8eb25e26.js" crossorigin="anonymous"></script>

  <link href="Style/Dashboard/dashstyle.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="Style/Dashboard/simple-sidebar.css" rel="stylesheet">
</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Awaxx Technologies</div>
      <div class="list-group list-group-flush">
        <a href="Dashboard.php" class="item list-group-item list-group-item-action"><span class="fa fa-dashboard"></span>  &nbsp;Dashboard</a>
        <a href="Sales.php" class="item list-group-item list-group-item-action"><span class="fas fa-cash-register"></span>  &nbsp;Sales Transactions</a>
        <a href="Products.php" class="item list-group-item list-group-item-action"><span class="fa fa-industry"></span>  &nbsp;Products Inventory</a>
        <a href="Purchases.php" class="item list-group-item list-group-item-action"><span class="fa fa-shopping-bag"></span> &nbsp;Purchases Management</a>
        <a href="Expenses.php" class="item list-group-item list-group-item-action"><span class="fas fa-wallet"></span> &nbsp;Expenses Management</a>
        <a href="Accounts.php" class="item list-group-item list-group-item-action"><span class="fas fa-file-alt	"></span> &nbsp;Accounts Management</a>
        <a href="Customers.php" class="item list-group-item list-group-item-action"><span class="fas fa-handshake"></span>&nbsp;Customers Management</a>
        <a href="Suppliers.php" class="item list-group-item list-group-item-action"><span class="fas fa-truck-moving"></span>  &nbsp;Suppliers Management</a>
        <a href="Employee.php" class="item list-group-item list-group-item-action"><span class="fas fa-user-tie"></span>  &nbsp;Employees Management</a>
        <a href="Users.php" class="item list-group-item list-group-item-action"><span class="fas fa-portrait"></span> &nbsp;Users Management</a>
        <a href="Profile.php" class="item-active list-group-item list-group-item-action"><span class="fas fa-address-card"></span>  &nbsp;Profile Settings</a>
        <a href="Dashboard.php?logout=1" class="logout item list-group-item list-group-item-action item"><span class="fas fa-sign-out-alt"></span> &nbsp;Logout</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
      <button style="width: 5rem;" class="tbtn btn btn-primary" id="menu-toggle"><span><i class="fa fa-reorder"></i></span></button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Profile Settings <span class="sr-only">(current)</span></a>
            </li>
            <li style=" color:#00b0d8;" class="nav-item nav-link">How's it going, <?php echo $_SESSION['username']; ?></li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">
        <h1 class="mt-4">Profile Settings</h1>
        <br>
        <div class="card">
          <div class="card-header text-center">
            <strong>Edit Your Profile Details</strong>
          </div>
          <div class="card-body">
            <h5 class="card-title text-center">Edit Profile Settings</h5>
            <p class="card-text text-center">Fill the fields below to edit your personal and login data.</p>
            <br>
            <form method="POST" action="Profile.php?editprofile">

                <div class="form-row">
                  <div class="form-group col-md-3">
                    <label for="profilename">Profile Name</label>
                    <input type="text" class="form-control" name="profilename" id="profilename"  placeholder="Type New Profile Name" value="<?php echo $_SESSION['username']; ?>" >
                  </div>
                  <div class="form-group col-md-3">
                    <label for="profileemail">Email Address</label>
                    <input type="email" class="form-control" name="profilemail" id="profileemail"  placeholder="Type New Profile Address" value="<?php echo $_SESSION['email']; ?>" >
                  </div>
                  <div class="form-group col-md-3">
                    <label for="profilephone">Phone Number</label>
                    <input type="tel" class="form-control" name="profilphone" id="profilephone" placeholder="Type New Profile Number" value="<?php echo $_SESSION['phone']; ?>">
                  </div>
                  <div class="form-group col-md-3 ">
                    <label for="profileaddr">Physical Address</label>
                      <input type="text" class="form-control" name="profiladdress" id="profileaddr" placeholder="Type Profile Physical Address" value="<?php echo $_SESSION['address']; ?>"  >
                  </div>
                </div>
                <button style="float:right" type="submit" class="tbtn btn btn-primary">Edit Profile Data</button>
              </form>
                <br>
                <form method="POST" action="Profile.php?Changepass">
                <fieldset>
                  <legend>Change Your Password</legend>
                  <br>
                  <div class="form-row ">
                    <div class="form-group col-md-3 ">
                      <label for="oldprofilepass">Old Profile Password</label>
                        <input type="password" class="form-control" name="oldprofilepass" id="oldprofilepass" required placeholder="Type Current Profile Password">
                    </div>
                  </div>
                <div class="form-row ">
              <div class="form-group col-md-3 ">
                <label for="profilepass">New Profile Password</label>
                  <input type="password" class="form-control" name="profilpass" id="profilepass"  required placeholder="Type New Profile Password">
              </div>
              <div class="form-group col-md-3 ">
                <label for="passconf">Confirm New Password</label>
                  <input type="password" class="form-control"  name="profilpassconf" id="passconf" required placeholder="Retype New Profile Password">
              </div>
            </div>

              <button type="submit" name="changepass-btn" class="tbtn btn btn-primary pass-btn">Change Password</button>


            </fieldset>
          </form>

          <div class="card-footer text-center text-muted">
            <?php echo date("Y-m-d H:i:s"); ?>
          </div>
        </div>
      </div>

    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>

</body>

</html>

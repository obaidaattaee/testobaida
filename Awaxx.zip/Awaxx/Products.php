<?php
  require_once 'controllers/authController.php';
  require_once 'controllers/productMgmt.php';
 // require_once 'SearchProduct.php';

    session_start();

if(!isset($_SESSION['id'])){
  header('location: Login.php');
  exit();

}

?>
<!DOCTYPE html>
<html lang="en" id="htmlitem">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Awaxx Technologies - Products Management System</title>

  <!-- Bootstrap core CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">

  <!--===============================================================================================-->
  <script src="https://kit.fontawesome.com/4f8eb25e26.js" crossorigin="anonymous"></script>

  <link href="Style/Dashboard/dashstyle.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="Style/Dashboard/simple-sidebar.css" rel="stylesheet">

</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Awaxx Technologies</div>
      <div class="list-group list-group-flush">
        <a href="Dashboard.php" class="item list-group-item list-group-item-action"><span class="fa fa-dashboard"></span>  &nbsp;Dashboard</a>
        <a href="Sales.php" class="item list-group-item list-group-item-action"><span class="fas fa-cash-register"></span>  &nbsp;Sales Transactions</a>
        <a href="Products.php" class="item-active list-group-item list-group-item-action"><span class="fa fa-industry"></span>  &nbsp;Products Inventory</a>
        <a href="Purchases.php" class="item list-group-item list-group-item-action"><span class="fa fa-shopping-bag"></span> &nbsp;Purchases Management</a>
        <a href="Expenses.php" class="item list-group-item list-group-item-action"><span class="fas fa-wallet"></span> &nbsp;Expenses Management</a>
        <a href="Accounts.php" class="item list-group-item list-group-item-action"><span class="fas fa-file-alt	"></span> &nbsp;Accounts Management</a>
        <a href="Customers.php" class="item list-group-item list-group-item-action"><span class="fas fa-handshake"></span>&nbsp;Customers Management</a>
        <a href="Suppliers.php" class="item list-group-item list-group-item-action"><span class="fas fa-truck-moving"></span>  &nbsp;Suppliers Management</a>
        <a href="Employee.php" class="item list-group-item list-group-item-action"><span class="fas fa-user-tie"></span>  &nbsp;Employees Management</a>
        <a href="Users.php" class="item list-group-item list-group-item-action"><span class="fas fa-portrait"></span> &nbsp;Users Management</a>
        <a href="Profile.php" class="item list-group-item list-group-item-action"><span class="fas fa-address-card"></span>  &nbsp;Profile Settings</a>
        <a href="Dashboard.php?logout=1" class="logout item list-group-item list-group-item-action item"><span class="fas fa-sign-out-alt"></span> &nbsp;Logout</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
      <button style="width: 5rem;" class="tbtn btn btn-primary" id="menu-toggle"><span><i class="fa fa-reorder"></i></span></button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Products Inventory Management <span class="sr-only">(current)</span></a>
            </li>
            <li style=" color:#00b0d8;" class="nav-item nav-link">How's it going,  <?php echo $_SESSION['username']; ?></li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">
        <h1 class="mt-4"><span class="fa fa-shopping-cart"></span>  &nbsp;Products Inventory Management</h1>
        <br>

        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
          <?php foreach ($errors as $error): ?>

          <li> <?php echo $error; ?> </li>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if(count($success) > 0): ?>
        <div class="alert alert-success">
          <?php foreach ($success as $succeses): ?>

          <li> <?php echo $succeses; ?> </li>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div style="margin-left: 2px;" class="card info"  style="width: 21rem; height: 15rem;" >
              <div class="card-body"  >
                  <h2 class="card-title"><span class="fa fa-bar-chart"></span> &nbsp; Latest Added Product</h1><br>
                    <button type="button" style="margin: 20px 50px;" id="#showaddproductmodal" class="mtbtn tbtn btn btn-primary" data-toggle="modal" data-target="#addProductModal"> Add new Product </button>
                    <button type="button" style="margin: 20px 50px; " id="#showeditproductmodal" class="mtbtn1 tbtn btn btn-primary" data-toggle="modal" data-target="#editProductModal"> Edit / Delete Product </button>
                  <!--  <form method="POST" action="Products.php?searchintable" class="searchTable" >
                      <span class="fa fa-search"></span>  Search Products:  &nbsp; <input type="text" class="searchProducts" name="searchProductsintable"  aria-label="Search Products" placeholder="Search Product by Code" >
                        <button type="submit" name="searchProductsintable-btn" class="tbtn btn btn-primary btn-search"> Search </button>
                    </form> -->
              <div class="table-responsive">
        <table style="text-align: center; margin-top:2%;" id="productstable" class="table cell-border order-column table-hover row-border">
  <thead>
    <tr>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">#</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Item Code</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Item Name</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Units Solds</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Product Cost</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Product Price</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Available Quantity</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Transaction Time</th>
      <th style="background-color: #00b0d8; color: #fff;" scope="col">Supplier ID</th>
    </tr>
  </thead>
  <tbody>

    <?php

        if(!isset($_POST['searchProductsintable-btn'])){
        $sqld = "SELECT ID, Code, Name, UnitsSold, Cost, Price, Quantity, TransactionTime, SupplierID FROM products  ORDER BY `products`.`TransactionTime` DESC";
        $resultd = $conn->query($sqld);
        if ($resultd->num_rows > 0) {
        // output data of each row
        while($row = $resultd->fetch_assoc()) {
        echo "<tr>
        <th>" . $row['ID']. "</th>
        <th>" . $row["Code"]. "</th>
        <td>" . $row["Name"] . " </td>
        <td>" . $row["UnitsSold"] . " </td>
        <td>" . $row["Cost"]. "</td>
        <td>" . $row["Price"]. "</td>
        <td>" . $row["Quantity"]. "</td>
        <td>" . $row["TransactionTime"]. "</td>
        <td>" . $row["SupplierID"]. "</td>
        </tr>";
        }

      }
        $conn->close();
      }
         ?>

  </tbody>
</table>
</div>

    </div>
    <!-- /#page-content-wrapper -->
  </div>
    <br>
    <!-- Modal -->
      <div class="modal fade" id="addProductModal" tabindex="-1" role="dialog" aria-labelledby="addProductLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class=" modal-title" id="addProductLabel"></h5>
              <button type="button" class="close" style="cursor: pointer !important;" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <div class="card">
                <div class="card-header text-center">
                  <strong> Record a New Product Items </strong>
                </div>
                <div class="card-body">
                  <h5 class="card-title text-center">Add New Product</h5>
                  <p class="card-text text-center">Fill the fileds below to add a new product.</p>
                  <br>
                  <form method="POST" action="Products.php?add" >
                      <div class="form-row">
                        <div class="form-group col-md-6">
                          <label for="itemcode">Item Code</label>
                          <input type="text" class="form-control" name="itemcode" id="itemcode" required placeholder="Input Product Code">
                        </div>
                        <div class="form-group col-md-6">
                          <label for="itemname">Item Name</label>
                          <input type="text" class="form-control"  name="itemname" id="itemname" required placeholder="Input Product Name">
                        </div>

                    </div>
                      <div class="form-row">

                        <div class="form-group col-md-6">
                          <label for="ucost"> Unit Cost </label>
                          <input type="number" min="0" class="form-control"  name="ucost" id="ucost"required  placeholder="Input Unit Cost">
                        </div>

                        <div class="form-group col-md-6">
                          <label for="uprice"> Unit Price </label>
                          <input type="number" min="0" class="form-control" name="uprice" id="uprice"required  placeholder="Input Unit Price">
                        </div>

                      </div>
                        <div class="form-row">
                          <div class="form-group col-md-6 ">
                            <label for="quan">Available Quantity</label>
                            <input type="number" min="0" class="form-control" name="quan"  id="quan" required placeholder="Product Quantity">
                          </div>
                        <div class="form-group col-md-6">
                        <label for="supplierid">Supplier ID</label>
                        <input type="number" min="1" class="form-control" name="supplierid"  id="supplierid" placeholder="Supplier Id">
                      </div>
                    </div>

                </div>
                <div class="card-footer text-center text-muted">
                  <?php echo date("Y-m-d H:i:s"); ?>
                </div>
              </div>

            </div>
            <div class="modal-footer">
              <button type="button" class="mbtn btn btn-secondary" data-dismiss="modal">Close</button>
              <button  type="submit" name="addProduct-btn" class="mbtn btn btn-primary">Add Product</button>
              </form>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal -->
        <div class="modal fade" id="editProductModal" tabindex="-1"  aria-hidden="true" data-backdrop="static" role="dialog" aria-labelledby="editProductLabel" aria-modal="true">
          <div class="modal-dialog " role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class=" modal-title" id="editProductLabel"></h5>
                <button type="button" class="close" style="cursor: pointer !important;" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="card">
                  <div class="card-header text-center">
                    <strong> Edit Existing Product Items </strong>
                  </div>
                  <div class="card-body">
                    <h5 class="card-title text-center">Edit Existing Product</h5>

                        <?php if(count($errors) > 0): ?>
                          <div class="alert alert-danger">
                             <?php echo $errors['notfound'];  ?>
                           </div>
                           <?php endif; ?>
                    <p class="card-text text-center">Search for item by code then edit existing product data by edit the fileds below. to delete the product just search for item by code then click on delete button.</p>
                    <br>
                    <form  method="POST" action="SearchProduct.php" >
                      <div class="form-row">
                          <div class="form-group col-md-8">
                            <label for="epitemcode">Item Code</label>
                            <input type="text" class="form-control producSearchField" name="eitemcode" id="epitemcode" required value="" placeholder="Input Product Code &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;  &#128270;">
                          </div><!-- Seaching -->
                          <div class="form-group col-md-3">
                            <button type="submit" onclick="event.preventDefault(); productSearch(document.getElementById('epitemcode').value);" style="width:9rem; margin-top: 32px;" name="searchProducts-btn" id="searchdata"  class="tbtn btn btn-primary btn-search"> Search </button>
                          </div>
                      </div>
                    </form>
                      <form  method="POST" action="Products.php?edit" >
                        <div class="form-row">
                          <div class="form-group col-md-12">
                            <label for="epitemname">Item Name</label>
                            <input type="text" class="form-control codefield" name="eitemcode" id="epitemcode" required value="<?php echo $_SESSION['sCode']; ?>" placeholder="Input Product Code &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;  &#128270;">
                          </div>
                        </div>
                      <div class="form-row">
                        <div class="form-group col-md-12">
                          <label for="epitemname">Item Name</label>
                          <input type="text" class="form-control" name="eitemname" id="epitemname"  value="<?php echo $_SESSION['sName']; ?>" placeholder="Input Product Name">
                        </div>
                      </div>
                        <div class="form-row">

                          <div class="form-group col-md-6">
                            <label for="epucost"> Unit Cost </label>
                            <input type="number" min="0" class="form-control"  name="eucost" id="epucost" value="<?php echo $_SESSION['sCost']; ?>"  placeholder="Input Unit Cost">
                          </div>

                          <div class="form-group col-md-6">
                            <label for="epuprice"> Unit Price </label>
                            <input type="number" min="0" class="form-control"  name="euprice" id="epuprice" value="<?php echo $_SESSION['sPrice']; ?>" placeholder="Input Unit Price">
                          </div>

                        </div>
                          <div class="form-row">
                            <div class="form-group col-md-6 ">
                              <label for="epquan">Product Quantity</label>
                              <input type="number" min="0" class="form-control" name="equan" id="epquan"  value="<?php echo $_SESSION['sQuantity']; ?>"  placeholder="Product Quantity">
                            </div>
                          <div class="form-group col-md-6">
                          <label for="epsupplierid">Supplier ID</label>
                          <input type="number" min="0" class="form-control"  name="esupplierid" id="epsupplierid" value="<?php echo $_SESSION['sSupplierID']; ?>" placeholder="Supplier ID">
                        </div>
                      </div>

                  </div>
                  <div class="card-footer text-center text-muted">
                    <?php echo date("Y-m-d H:i:s"); ?>
                  </div>
                </div>

              </div>
              <div class="modal-footer">
                <button type="button" class="mbtn btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" name="deleteProduct-btn" class="mbtn btn btn-primary">Delete Product</button>
                <button  type="submit" name="editProduct-btn" class="mbtn btn btn-primary">Send New Product Data</button>
              </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script
			  src="https://code.jquery.com/jquery-3.5.1.js"
			  integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc="
			  crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" ></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>
  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" ></script>
  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
    $(document).ready(function () {
  $('#productstable').DataTable();
  $('.dataTables_length').addClass('bs-select');
});
$("#searchdata").submit(function(e) {
e.preventDefault();
  $("#editProductModal").modal({show: true});
});

$('#productstable').dataTable({
  'iDisplayLength': 50
});
  </script>
<script>
function productSearch(product){
  console.log(product);
  $.ajax({
      type: 'POST',
      url: "SearchProduct.php",
      data: {
          'eitemcode': product,
      },
      success: function (data) {
        var product = JSON.parse(data);
        console.log(product);
        console.log(product.sName);
        $(".codefield").attr('value' , product.sCode) ;
        $("#epitemname").attr('value' ,  product.sName) ;
        $("#epucost").attr('value' , product.sCost) ;
        $("#epuprice").attr('value' ,  product.sPrice) ;
        $("#epquan").attr('value' , product.sQuantity) ;
        $("#epsupplierid").attr('value' ,  product.sSupplierID) ;
      }
  });
}
</script>

</body>

</html>

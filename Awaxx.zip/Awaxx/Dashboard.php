<?php
require_once 'controllers/authController.php';
    session_start();

if(!isset($_SESSION['id'])){
  header('location: Login.php');
  exit();

}

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Awaxx Technologies - Management System Dashboard</title>

  <!-- Bootstrap core CSS -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
    <script src="https://kit.fontawesome.com/4f8eb25e26.js" crossorigin="anonymous"></script>  <!-- Custom styles for this template -->
  <link href="Style/Dashboard/simple-sidebar.css" rel="stylesheet">
  <link href="Style/Dashboard/dashstyle.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>

</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Awaxx Technologies</div>
      <div class="list-group list-group-flush">
        <a href="Dashboard.php" class="item-active list-group-item list-group-item-action"><span class="fa fa-dashboard"></span>  &nbsp;Dashboard</a>
        <a href="Sales.php" class="item list-group-item list-group-item-action"><span class="fas fa-cash-register"></span>  &nbsp;Sales Transactions</a>
        <a href="Products.php" class="item list-group-item list-group-item-action"><span class="fa fa-industry"></span>  &nbsp;Products Inventory</a>
        <a href="Purchases.php" class="item list-group-item list-group-item-action"><span class="fa fa-shopping-bag"></span> &nbsp;Purchases Management</a>
        <a href="Expenses.php" class="item list-group-item list-group-item-action"><span class="fas fa-wallet"></span> &nbsp;Expenses Management</a>
        <a href="Accounts.php" class="item list-group-item list-group-item-action"><span class="fas fa-file-alt	"></span> &nbsp;Accounts Management</a>
        <a href="Customers.php" class="item list-group-item list-group-item-action"><span class="fas fa-handshake"></span>&nbsp;Customers Management</a>
        <a href="Suppliers.php" class="item list-group-item list-group-item-action"><span class="fas fa-truck-moving"></span>  &nbsp;Suppliers Management</a>
        <a href="Employee.php" class="item list-group-item list-group-item-action"><span class="fas fa-user-tie"></span>  &nbsp;Employees Management</a>
        <a href="Users.php" class="item list-group-item list-group-item-action"><span class="fas fa-portrait"></span> &nbsp;Users Management</a>
        <a href="Profile.php" class="item list-group-item list-group-item-action"><span class="fas fa-address-card"></span>  &nbsp;Profile Settings</a>
        <a href="Dashboard.php?logout=1" class="logout item list-group-item list-group-item-action item"><span class="fas fa-sign-out-alt"></span> &nbsp;Logout</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
      <button style="width: 5rem;" class="tbtn btn btn-primary" id="menu-toggle"><span><i class="fa fa-reorder"></i></span></button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Dashboard <span class="sr-only">(current)</span></a>
            </li>
            <li style=" color:#00b0d8;" class="nav-item nav-link">How's it going,  <?php echo $_SESSION['username']; ?></li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">
        <h1 class="mt-4"><span class="fa fa-dashboard"></span>  &nbsp;Dashboard</h1>
          <div id="cardset" class="container" style="padding-left:12%;">
            <div class="row">
                <div class="col-md-4 col-xl-3">
                    <div class="card bg-c-mint order-card">
                        <div class="card-block">
                            <h6 class="m-b-20">Total Profit</h6>
                            <h2 class="text-right"><i class="fa fa-line-chart f-left"></i><span>486</span> <span> <i class="fas fa-shekel-sign"></i></span></h2>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-xl-3">
                    <div class="card bg-c-lighgreen order-card">
                        <div class="card-block">
                            <h6 class="m-b-20">Total Revenue</h6>
                            <h2 class="text-right"><i class="fas fa-comment-dollar f-left"></i><span>486</span><span> <i class="fas fa-shekel-sign"></i></span></h2>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-xl-3">
                    <div class="card bg-c-vio order-card">
                        <div class="card-block">
                            <h6 class="m-b-20">Total Expenses</h6>
                            <h2 class="text-right"><i class="fas fa-file-invoice f-left"></i><span>486</span><span> <i class="fas fa-shekel-sign"></i></span></h2>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-xl-3">
                    <div class="card bg-c-red order-card">
                        <div class="card-block">
                            <h6 class="m-b-20">Accounts Receivable</h6>
                            <h2 class="text-right"><i class="fas fa-hand-holding-usd f-left"></i><span>486</span><span> <i class="fas fa-shekel-sign"></i></span></h2>
                        </div>
                    </div>
                </div>
        	</div>
          <div class="row" style="margin-top: -15%">
              <div class="col-md-4 col-xl-3">
                  <div class="card bg-c-darkgreen order-card">
                      <div class="card-block">
                          <h6 class="m-b-20">Current Cash </h6>
                          <h2 class="text-right"><i class="fas fa-coins f-left"></i><span>486</span><span> <i class="fas fa-shekel-sign"></i></span></h2>
                      </div>
                  </div>
              </div>

              <div class="col-md-4 col-xl-3">
                  <div class="card bg-c-limegreen order-card">
                      <div class="card-block">
                          <h6 class="m-b-20"> Cash inflow</h6>
                          <h2 class="text-right"><i class="fas fa-donate f-left"></i><span>486</span><span> <i class="fas fa-shekel-sign"></i></span></h2>
                      </div>
                  </div>
              </div>

              <div class="col-md-4 col-xl-3">
                  <div class="card bg-c-orange order-card">
                      <div class="card-block">
                          <h6 class="m-b-20">Cash outflow</h6>
                          <h2 class="text-right"><i class="fas fa-money-bill-wave f-left"></i><span>486</span><span> <i class="fas fa-shekel-sign"></i></span></h2>
                      </div>
                  </div>
              </div>

              <div class="col-md-4 col-xl-3">
                  <div class="card bg-c-pink order-card">
                      <div class="card-block">
                          <h6 class="m-b-20">Accounts Payable</h6>
                          <h2 class="text-right"><i class="fas fa-money-check-alt f-left"></i><span>486</span><span> <i class="fas fa-shekel-sign"></i></span></h2>
                      </div>
                  </div>
              </div>
        </div>
        <div class="row" style="margin-top: -15%">
            <div class="col-md-4 col-xl-3">
                <div class="card bg-c-aqua order-card">
                    <div class="card-block">
                        <h6 class="m-b-20">Total Sales Transaction</h6>
                        <h2 class="text-right"><i class="fa fa-exchange f-left"></i><span>486</span></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-xl-3">
                <div class="card bg-c-yellow order-card">
                    <div class="card-block">
                        <h6 class="m-b-20">Total Purshase Transaction</h6>
                        <h2 class="text-right"><i class="fa fa-cart-plus f-left"></i><span>486</span></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-xl-3">
                <div class="card bg-c-darkblue order-card">
                    <div class="card-block">
                        <h6 class="m-b-20">Total Number of Employees</h6>
                        <h2 class="text-right"><i class="fas fa-user-tie f-left"></i><span>486</span></h2>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-xl-3">
                <div class="card bg-c-darkvio order-card">
                    <div class="card-block">
                        <h6 class="m-b-20">Total Number of System User</h6>
                        <h2 class="text-right"><i class="fas fa-chalkboard-teacher f-left"></i><span>486</span></h2>
                    </div>
                </div>
            </div>

      </div>
        </div>



        <div class="container">

          <div style="padding-left: 15%;" class="row">
            <!-- Card -->

            <div id="incomevsexp" class="card chart-card col-md-3 col-xl-4" >

              <!-- Card content -->
              <div class="card-body pb-0">

                <!-- Title -->
                <h4 class="card-title font-weight-bold"><i class="fa fa-pie-chart" ></i><span> &nbsp; Income vs Expenses Graph<span></h4>
                <!-- Text -->
                <p class="card-text mb-4">NYSE: AZHC  •  Oct 16, 1:45PM</p>
                  <!-- <div class="d-flex justify-content-between">
                  <p class="display-4 align-self-end">887.32</p>
                  <p class="align-self-end pb-2">887.02 (.03%)</p>
                </div> -->

              </div>

            <!-- Classic tabs -->
            <div class="classic-tabs">


              <div class="tab-content rounded-bottom">
                <!--Panel 1-->
                <div class="tab-pane fade in show active" id="panel1001" role="tabpanel">
                  <canvas id="inexp" height="450px"></canvas>
                </div>
                <!--/.Panel 1-->


              </div>

            </div>
            <!-- Classic tabs -->

          </div>
          <!-- Card -->

        <!-- Card -->

                    <!-- Card -->
              <div id="customervalue-c" class="card chart-card col-md-8 col-xl-4" >

              <!-- Card content -->
              <div class="card-body pb-0">

              <!-- Title -->
              <h4 class="card-title font-weight-bold"><i class="fa fa-bar-chart" ></i><span> &nbsp;Most Customers Value</span></h4>
              <!-- Text -->
              <p class="card-text mb-4">NYSE: AZHC  •  Oct 16, 1:45PM</p>
              <div class="d-flex justify-content-between">
              <!-- <p class="display-4 align-self-end">887.32</p>
              <p class="align-self-end pb-2">887.02 (.03%)</p>
              </div>  -->

              </div>

              <div class="tab-content rounded-bottom">
              <!--Panel 1-->
              <div class="tab-pane fade in show active" id="panel1001" role="tabpanel">
              <canvas id="c_ranks" height="550px" width="350px"></canvas>
              </div>

              </div>

              </div>
              <!-- Classic tabs -->

              </div>
              <!-- Card -->
          </div>
        </div>


      <script src="js/Charts/charts.js"></script>

    </div>
    <!-- /#page-content-wrapper -->
  </div>
</div>

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>

</body>

</html>

<?php
require_once 'controllers/authController.php';
    session_start();

if(!isset($_SESSION['id'])){
  header('location: Login.php');
  exit();

}

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Awaxx Technologies - Customers Management System</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--===============================================================================================-->
  <script src="https://kit.fontawesome.com/4f8eb25e26.js" crossorigin="anonymous"></script>

  <!-- Custom styles for this template -->
  <link href="Style/Dashboard/simple-sidebar.css" rel="stylesheet">

</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Awaxx Technologies</div>
      <div class="list-group list-group-flush">
        <a href="Dashboard.php" class="item list-group-item list-group-item-action"><span class="fa fa-dashboard"></span>  &nbsp;Dashboard</a>
        <a href="Sales.php" class="item list-group-item list-group-item-action"><span class="fas fa-cash-register"></span>  &nbsp;Sales Transactions</a>
        <a href="Products.php" class="item list-group-item list-group-item-action"><span class="fa fa-industry"></span>  &nbsp;Products Inventory</a>
        <a href="Purchases.php" class="item list-group-item list-group-item-action"><span class="fa fa-shopping-bag"></span> &nbsp;Purchases Management</a>
        <a href="Expenses.php" class="item list-group-item list-group-item-action"><span class="fas fa-wallet"></span> &nbsp;Expenses Management</a>
        <a href="Accounts.php" class="item list-group-item list-group-item-action"><span class="fas fa-file-alt	"></span> &nbsp;Accounts Management</a>
        <a href="Customers.php" class="item list-group-item list-group-item-action"><span class="fas fa-handshake"></span>&nbsp;Customers Management</a>
        <a href="Suppliers.php" class="item list-group-item list-group-item-action"><span class="fas fa-truck-moving"></span>  &nbsp;Suppliers Management</a>
        <a href="Employee.php" class="item-active list-group-item list-group-item-action"><span class="fas fa-user-tie"></span>  &nbsp;Employees Management</a>
        <a href="Users.php" class="item list-group-item list-group-item-action"><span class="fas fa-portrait"></span> &nbsp;Users Management</a>
        <a href="Profile.php" class="item list-group-item list-group-item-action"><span class="fas fa-address-card"></span>  &nbsp;Profile Settings</a>
        <a href="Dashboard.php?logout=1" class="logout item list-group-item list-group-item-action item"><span class="fas fa-sign-out-alt"></span> &nbsp;Logout</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
      <button style="width: 5rem;" class="tbtn btn btn-primary" id="menu-toggle"><span><i class="fa fa-reorder"></i></span></button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="Employee.php">Employee Management <span class="sr-only">(current)</span></a>
            </li>
            <li style=" color:#00b0d8;" class="nav-item nav-link">How's it going,  <?php echo $_SESSION['username']; ?></li>
          </ul>
        </div>
      </nav>

      <div class="container-fluid">
        <h1 class="mt-4">Employee Management</h1>
        <br>
        <div class="card">
          <div class="card-header text-center">
            <strong>Record New Employee Details</strong>
          </div>
          <div class="card-body">
            <h5 class="card-title text-center">Add a new Employee</h5>
            <p class="card-text text-center">Fill the fileds below to add a new Admin.</p>
            <br>
            <form>

                <div class="form-row">
                  <div class="form-group col-md-3">
                    <label for="adminname">Admin Name</label>
                    <input type="text" class="form-control" id="adminname" required placeholder="Input Admin Name">
                  </div>
                  <div class="form-group col-md-3">
                    <label for="adminemail">Email Address</label>
                    <input type="email" class="form-control" id="adminemail" required placeholder="Input Admin Email Address">
                  </div>
                  <div class="form-group col-md-3">
                    <label for="adminphone">Phone Number</label>
                    <input type="tel" class="form-control" id="adminphone" placeholder="Input Admin Phone Number">
                  </div>
                </div>
                  <div class="form-row">
                <div class="form-group col-md-3 ">
                  <label for="adminaddr">Physical Address</label>
                    <input type="text" class="form-control" id="adminaddr" placeholder="Type Admin Physical Address">
                </div>
                <div class="form-group col-md-3 ">
                  <label for="adminpass">Admin Password</label>
                    <input type="password" class="form-control" id="adminpass" required placeholder="Type Admin Password">
                </div>
                <div class="form-group col-md-3 ">
                  <label for="passconf">Confirm Password</label>
                    <input type="password" class="form-control" id="passconf" required placeholder="Retype Admin Password">
                </div>

              </div>
                <button style="float:right" type="submit" class="tbtn btn btn-primary">Add System User</button>
              </form>
          </div>
          <div class="card-footer text-center text-muted">
            <?php echo date("Y-m-d H:i:s"); ?>
          </div>
        </div>
        <br>
        <div style="margin-left: 15px;" class="card info"  style="width: 20rem; height: 15rem;" >
              <div class="card-body"  >
                  <h2 class="card-title"><span class="fa fa-bar-chart"></span> &nbsp; Latest Added Employee </h1><br>
              <div class="table-responsive-md">
				<table style="text-align: center;" class="table table-hover">
  <thead>
    <tr>
      <th style="background-color: #444444; color: #fff;" scope="col">#</th>
      <th style="background-color: #444444; color: #fff;" scope="col">Admin Name</th>
      <th style="background-color: #444444; color: #fff;"scope="col">Admin Phone</th>
      <th style="background-color: #444444; color: #fff;" scope="col">Admin Email</th>
      <th style="background-color: #444444; color: #fff;" scope="col">Admin Address</th>
      <th style="background-color: #444444; color: #fff;" scope="col">Transaction Time</th>
    </tr>
  </thead>
  <tbody>
    <?php
        $Duser_id = $_SESSION['id'];
        $sqld = "SELECT Did, Amount, Tr_Type, D_Paymant,D_Date, Status FROM deposit_tr WHERE Duserid = '$Duser_id' AND  Amount <> '' ";
        $resultd = $conn->query($sqld);
        if ($resultd->num_rows > 0) {
        // output data of each row
        while($row = $resultd->fetch_assoc()) {
        echo "<tr>
        <th>" . $row["Did"]. "</th>
        <td>" . $row["Amount"] . " </td>
        <td>" . $row["Tr_Type"]. "</td>
        <td>" . $row["D_Paymant"]. "</td>
        <td>" . $row["D_Date"]. "</td>
        <td>" . $row["Status"]. "</td>
        </tr>";
        }


        echo "</table>";
      } else { echo '<div style="color: #1ebba3;"> 0 results </div>';}
        $conn->close();
        ?>

  </tbody>
</table>
</div>

    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>

</body>

</html>
